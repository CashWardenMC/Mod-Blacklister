package com.cashwarden.modblacklister;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.networking.v1.ClientLoginNetworking;
import net.fabricmc.fabric.api.networking.v1.PacketByteBufs;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.class_2540;
import net.minecraft.class_2960;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.CompletableFuture;

public class ClientModBlacklister implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        ClientLoginNetworking.registerGlobalReceiver(class_2960.method_60655("modblacklister", "mod_list"), (client, handler, buf, listenerAdder) -> {
            Map<String, String> modList = new HashMap<>();
            // Populate with all loaded mods
            FabricLoader.getInstance().getAllMods().forEach(mod -> modList.put(mod.getMetadata().getId(), mod.getMetadata().getVersion().getFriendlyString()));
            class_2540 responseBuf = PacketByteBufs.create();
            responseBuf.method_34063(modList, class_2540::method_10814, class_2540::method_10814);
            return CompletableFuture.completedFuture(responseBuf);
        });
    }
}